# Configuración de Visual Studio Code

He agregado una carpeta llamada `.vscode` que tiene un archivo llamado `settings.json`. He configurado las extensiones para que vayamos trabajando con lo mismo.

Si no tienes el entorno virtual creado, puedes abrir el archivo `requirements.txt` con Visual Studio Code y hacer clic en **Crear ambiente**, luego elegir `Venv`, luego el intérprete Python (última versión), y finalmente pregunta por las dependencias: elegimos requirements.txt.

[Volver](../README.md)
