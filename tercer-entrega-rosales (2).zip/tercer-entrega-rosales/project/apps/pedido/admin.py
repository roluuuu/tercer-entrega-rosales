from django.contrib import admin
from .models import Pedido

admin.site.register(Pedido)

