from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpRequest
from .forms import PedidoForm
from .models import Pedido

def index(request: HttpRequest) -> HttpResponse:
    pedidos = Pedido.objects.all()
    return render(request, 'pedido/index.html', {'pedidos': pedidos})

def crear_pedido(request: HttpRequest) -> HttpResponse:
    if request.method == 'POST':
        form = PedidoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('pedido:index')
    else:
        form = PedidoForm()
    return render(request, 'pedido/crear_pedido.html', {'form': form})
