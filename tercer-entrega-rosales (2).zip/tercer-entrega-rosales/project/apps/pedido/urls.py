from django.urls import path
from . import views

urlpatterns = [
    path("pedido", views.index, name="index"),
    path("crear_pedido", views.crear_pedido, name="crear_pedido"),]