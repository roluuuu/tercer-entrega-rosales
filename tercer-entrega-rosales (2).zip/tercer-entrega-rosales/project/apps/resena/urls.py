from django.urls import path
from . import views

app_name = 'resena'

urlpatterns = [
    path('resenas/', views.index, name='index'),
]

