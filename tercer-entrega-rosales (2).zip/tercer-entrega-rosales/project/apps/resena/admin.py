from django.contrib import admin
from .models import Resena

admin.site.register(Resena)
